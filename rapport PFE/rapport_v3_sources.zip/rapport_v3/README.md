# Rapport PFE v3 — sources LaTeX (rapport-main-v3.pdf)

Compilation (MiKTeX ou TeX Live) : pdflatex main.tex  (trois passes)

- main.tex : préambule (charte ESPRIT : Times 12, marges 2,5 cm, interligne 1,15, pagination n/N),
  macros, styles TikZ, ordre des pages (garde, confidentialité, dépôt, corps, bibliographie, annexes, page de fin)
- chapitres/ : 00_frontmatter, 01_intro_generale, ch1..ch6, 07_conclusion_generale, 08_bibliographie, 09_annexes
- figs/ : figures d'origine, captures anonymisées (cap_*.png), pages signées (cover_pages.pdf, front_pages.pdf, back_cover.pdf, attestation.pdf non incluse)

Points à traiter avant dépôt : voir AUDIT_RAPPORT.md, section 8.4.
